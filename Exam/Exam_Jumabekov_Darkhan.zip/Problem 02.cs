﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Exam {
  internal class Problem_02 {
    /*
     Problem 02
      В массиве случайных целых чисел размером size = 100_000_000 найдите все отрицательные числа, встречающиеся менее n раз.
      int[] GetNumbers(int[] arr, int n)
     */

    public static int[] GetNumbers(int[] arr, int n) {
      List<int> res = new List<int>();
      for (int i = 0; i < arr.Length; i++) {
        int countNegativeNum = 0;
        int current = arr[i];
        if (current < 0 & !res.Contains(current)) {
          for (int j = 0; j < arr.Length; j++) {
            if (current == arr[j]) {
              countNegativeNum++;
              if (countNegativeNum >= n) break;
            }
          }
          if (countNegativeNum < n) {
            res.Add(current);
          }
        }
      }        
      return res.ToArray();
    }
    public static void Demo() {


      int[] arr = Utils.GetIntArray(100_000_000, -10, 10);
      int[] res = GetNumbers(arr, 10000);
      foreach (var item in res) {
        Write($"{item}, ");
      }



    }
  }
}
