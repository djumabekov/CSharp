﻿global using static System.Console;

namespace Exam;
class Program {

  static void Main(string[] args) {
    try {
      /*
     Problem 01
      Найдите строки матрицы размером 10_000 * 10_000, содержащие наибольшее количество отрицательных чисел.  
      */
      //Problem_01.Demo();
      //Problem_02.Demo();
      Problem_03.Demo();


    } catch (Exception ex) {
      WriteLine(ex.Message);
    }
    WriteLine("\nEnd . . .");
    ReadLine();
  }
}
